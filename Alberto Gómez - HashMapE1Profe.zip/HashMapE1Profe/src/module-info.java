/**
 * 
 */
/**
 * 
 */
module HashMapE1Profe {
	requires java.desktop;
}